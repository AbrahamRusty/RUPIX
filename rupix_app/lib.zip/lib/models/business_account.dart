import 'package:flutter/material.dart';

class BusinessAcc {
  final String title;
  final IconData lead;

  BusinessAcc({required this.title, required this.lead});
}
